# Person Detection 2 > 2024-01-03 5:20am
https://universe.roboflow.com/person-jaoyb/person-detection-2-ms1yv

Provided by a Roboflow user
License: Public Domain

